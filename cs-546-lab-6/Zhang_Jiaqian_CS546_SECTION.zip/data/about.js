const information = {
    "name": "Jiaqian Zhang",
    "cwid": "10440712",
    "biography": "My name is Jiaqian Zhang, CWID is 10440712, who have the enthusiastic on coding.\nI'm a 29 years-old guy and from China.",
    "favoriteShows": ["The Big Bang Theory",
                        "Modern family",
                        "The walking dead"],
    "hobbies": ["play computer games", "play basketball", "sing songs"]
}

module.exports = information;