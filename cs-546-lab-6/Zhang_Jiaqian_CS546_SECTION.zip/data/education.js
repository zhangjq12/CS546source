let edu = [
    {
        "schoolName": "The Affiliated High School of Shanxi University",
        "degree": "High School",
        "favoriteClass": "Math",
        "favoriteMemory": "Doing exams every day"
    },
    {
        "schoolName": "Central South University",
        "degree": "Bachelor",
        "favoriteClass": "Data Structure",
        "favoriteMemory": "Hang out with friends"
    },
    {
        "schoolName": "Stevens Institute of Technology",
        "degree": "Master",
        "favoriteClass": "Web Programming",
        "favoriteMemory": "Do coding every day"
    }
];

module.exports = edu;