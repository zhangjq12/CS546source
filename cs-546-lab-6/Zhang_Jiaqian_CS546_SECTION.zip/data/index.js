const story = require("./story");
const about = require("./about");
const edu = require("./education");

module.exports = {
    story: story,
    about: about,
    education: edu
}